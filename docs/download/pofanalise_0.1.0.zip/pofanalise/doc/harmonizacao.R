## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", echo = FALSE, message = FALSE, warning = FALSE)
library(pofanalise)
library(data.table)
f1 <- function(x) formatC(x, format = "f", digits = 1, decimal.mark = ",")
f2 <- function(x) formatC(x, format = "f", digits = 2, decimal.mark = ",")
cmp <- pof_resultado("comparacao_ibge")
cv  <- pof_resultado("comparacao_versoes")
mp  <- pof_resultado("mapeamento")
k <- function(item, col) cmp[Item == item][[col]]

## ----echo = TRUE, eval = FALSE------------------------------------------------
# h <- pof_harmonizacao()          # v2, com as correções de pof_correcoes()
# h$folhas[qualidade != "Alta"]    # folhas que pedem cuidado
# b <- pof_ler_edicao(2017, dir = "HarmonizaPOF2026_data", harmonizacao = h)
# attr(b, "mapeamento")            # proporção do valor que casou com o de-para

## -----------------------------------------------------------------------------
knitr::kable(pof_correcoes(), col.names = c("Ano", "Código", "Folha de destino", "Item"))

## -----------------------------------------------------------------------------
x <- cmp[, .(Grupo = Item, IBGE = f1(Oficial_2017),
             `Cod_harmo antigo` = f1(`Cod_harmo antigo_2017-2018`),
             `v2 original` = f1(`v2 original_2017-2018`),
             `v2 com correções` = f1(`v2 com correções_2017-2018`))]
setorder(x, -IBGE)
knitr::kable(x, align = "lrrrr", caption = "Participação na despesa de consumo, Brasil, 2017-2018 (%)")

