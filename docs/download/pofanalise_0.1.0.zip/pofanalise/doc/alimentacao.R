## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE, message = FALSE, warning = FALSE, fig.width = 8, fig.height = 5.5, out.width = "100%")
library(pofanalise); library(data.table); library(ggplot2)
a <- pof_resultado("alimentacao_rms")[, Nome := pof_rotulo(Item)]
aq <- pof_resultado("alimentacao_quintil_2017")[, Nome := pof_rotulo(Item)]
av <- function(nm, ed) a[Nome == nm & Edicao == ed]$Perc
aqv <- function(nm, k) aq[Nome == nm & Nivel == k]$Perc
fonte <- "Fonte: IBGE, POF 1987-2018, microdados harmonizados (harmonização v2 de Arthur Welle). Pacote pofanalise."
var <- dcast(a[Item != "f16104"], Nome ~ Edicao, value.var = "Perc")[, Var := `2017-2018` - `1987-1988`][order(Var)]

## -----------------------------------------------------------------------------
var[, Nome := factor(Nome, levels = Nome)]
ggplot(var, aes(Var, Nome, fill = Var > 0)) + geom_col(width = 0.7) +
  scale_fill_manual(values = c(`TRUE` = "#1c5cab", `FALSE` = "#c4462c"), guide = "none") +
  labs(title = "Mudança na cesta alimentar, RMs, 1987-1988 a 2017-2018",
       x = "Variação da participação no gasto alimentar (p.p.)", y = NULL, caption = fonte) + pof_tema()

## -----------------------------------------------------------------------------
x <- dcast(aq, Nome ~ Nivel, value.var = "Perc")
x[, (2:6) := lapply(.SD, pof_fmt), .SDcols = 2:6]
knitr::kable(x, col.names = c("Categoria", paste0(1:5, "º quintil")), align = "lrrrrr",
             caption = "Composição do gasto alimentar por quintil, Brasil, 2017-2018 (%). Refeição é parte de Outros produtos.")

## ----echo = TRUE, eval = FALSE------------------------------------------------
# pof_participacao(bs, c(sprintf("n%02d", 1:16), "f16104"), den = "Alimentação", filtro = quote(!is.na(RGMT)))
# # ou, com a camada de pesquisa:
# dados <- pof_carregar(dir = dir, itens = list(refeicao = "16104"))
# plot(pof_analisar(dados, "refeicao", medida = "participacao", por = "quintil"))

