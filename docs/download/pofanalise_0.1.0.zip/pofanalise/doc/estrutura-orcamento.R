## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE, message = FALSE, warning = FALSE, fig.width = 8, fig.height = 5, out.width = "100%")
library(pofanalise); library(data.table); library(ggplot2)
g <- pof_resultado("grupos")
sa <- g[Recorte == "RMs, sem aluguel"]
br <- g[Recorte == "Brasil"]
v <- function(it, ed) sa[Item == it & Edicao == ed]$Perc
fonte <- "Fonte: IBGE, POF 1987-2018, microdados harmonizados (harmonização v2 de Arthur Welle). Pacote pofanalise."

## -----------------------------------------------------------------------------
d <- copy(sa)
d[, Item := factor(Item, levels = d[Edicao == "2017-2018"][order(Perc)]$Item)]
ggplot(d, aes(Perc, Item, fill = Edicao)) +
  geom_col(position = position_dodge(0.82), width = 0.78) +
  scale_fill_manual(values = pof_cores_edicao()) +
  labs(title = "Participação dos grupos no consumo sem aluguel, RMs",
       x = "% da despesa de consumo (exclui aluguel)", y = NULL, fill = NULL, caption = fonte) + pof_tema()

## -----------------------------------------------------------------------------
x <- dcast(sa, Item ~ Edicao, value.var = "Perc")
x[, (2:6) := lapply(.SD, pof_fmt), .SDcols = 2:6]
knitr::kable(x, col.names = c("Grupo", names(x)[-1]), align = "lrrrrr",
             caption = "Participação no consumo sem aluguel, conjunto das RMs (%)")

## -----------------------------------------------------------------------------
x <- br[, .(Item, Edicao, v = paste0(pof_fmt(Perc), " [", pof_fmt(IC_inf), "; ", pof_fmt(IC_sup), "]"))]
x <- dcast(x, Item ~ Edicao, value.var = "v")
knitr::kable(x, col.names = c("Grupo", names(x)[-1]), align = "lrrr",
             caption = "Participação na despesa de consumo, Brasil, com IC 95% (%)")

## ----echo = TRUE, eval = FALSE------------------------------------------------
# b <- pof_somar_grupos(pof_ler_edicao(2017, dir, pof_harmonizacao()))
# pof_participacao(b, pof_grupos_consumo())                                 # Brasil
# bs <- pof_sem_aluguel(b)
# pof_participacao(bs, pof_grupos_consumo(), filtro = quote(!is.na(RGMT)))  # RMs

