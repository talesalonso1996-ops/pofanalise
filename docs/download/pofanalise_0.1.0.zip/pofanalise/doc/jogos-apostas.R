## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE, message = FALSE, warning = FALSE, fig.width = 8, fig.height = 5, out.width = "100%")
library(pofanalise); library(data.table); library(ggplot2)
se <- pof_resultado("apostas_serie")
pv <- pof_resultado("apostas_prevalencia_perfil")
pa <- pof_resultado("apostas_participacao_perfil")
va <- pof_resultado("apostas_variacao")
mo <- pof_resultado("apostas_modelo")[Edicao == "2017-2018"]
mg <- pof_resultado("apostas_modelo_gasto")
co <- pof_resultado("apostas_concentracao")
s_ <- function(rec, ed, col = "Estimativa") se[Recorte == rec & Edicao == ed][[col]]
p_ <- function(ct, gr, ed = "2017-2018") pv[Corte == ct & Grupo == gr & Edicao == ed]$Estimativa
m_ <- function(t, col = "Estimativa") mo[Termo == t][[col]]
fonte <- "Fonte: IBGE, POF 2002-2018, microdados harmonizados (folha 26101 da harmonização v2). Pacote pofanalise."

## -----------------------------------------------------------------------------
d <- pv[Corte == "quintil"]
ggplot(d, aes(Grupo, Estimativa, color = Edicao, group = Edicao)) +
  geom_line(linewidth = 1, position = position_dodge(0.3)) + geom_point(size = 2, position = position_dodge(0.3)) +
  geom_errorbar(aes(ymin = IC_inf, ymax = IC_sup), width = 0.2, position = position_dodge(0.3)) +
  scale_color_manual(values = pof_cores_edicao()) +
  labs(title = "UCs com gasto em jogos e apostas, por quintil, Brasil", subtitle = "Barras: IC 95% do desenho amostral",
       x = "Quintil de consumo per capita", y = "% das UCs", color = NULL, caption = fonte) + pof_tema()

## -----------------------------------------------------------------------------
x <- mo[Termo != "(Intercept)", .(Termo, `Razão de chances` = pof_fmt(Estimativa, 2),
        `IC 95%` = paste(pof_fmt(IC_inf, 2), "a", pof_fmt(IC_sup, 2)), p = ifelse(p_valor < 0.001, "< 0,001", pof_fmt(p_valor, 3)))]
knitr::kable(x, align = "lrrr", caption = "Chance de ter gasto com jogos e apostas, Brasil, 2017-2018. Referências: 1º quintil, homem, branca, 30 a 44 anos, 1 morador.")

## -----------------------------------------------------------------------------
x <- va[, .(Corte, Grupo, `2002-2003` = pof_fmt(De), `2017-2018` = pof_fmt(Para), `Diferença (p.p.)` = pof_fmt(Diferenca),
            p = pof_fmt(p_valor, 3), Significativa = fifelse(Significativa, "sim", "não"))]
knitr::kable(x, align = "llrrrrl", caption = "Variação da prevalência de gasto com jogos e apostas, Brasil")

## ----echo = TRUE, eval = FALSE------------------------------------------------
# dados <- pof_carregar(c(2002, 2008, 2017), dir, itens = list(apostas = "26101"))
# plot(pof_analisar(dados, "apostas", por = "quintil"))
# pof_modelo(dados["2017-2018"], "apostas", ~ quintil + sexo + cor + idade + tamanho)
# pof_variacao(pof_analisar(dados, "apostas", por = "quintil"), "2002-2003", "2017-2018")

