## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE, message = FALSE, warning = FALSE, fig.width = 8, fig.height = 5, out.width = "100%")
library(pofanalise); library(data.table); library(ggplot2)
q <- pof_resultado("quintis_rms")
e <- pof_resultado("engel")
qv <- function(it, ed, k) q[Item == it & Edicao == ed & Nivel == k]$Perc
rz <- function(it, ed) qv(it, ed, 1) / qv(it, ed, 5)
el <- function(gr, ed) e[Grupo == gr & Edicao == ed]$elasticidade
fonte <- "Fonte: IBGE, POF 1987-2018, microdados harmonizados (harmonização v2 de Arthur Welle). Pacote pofanalise."

## -----------------------------------------------------------------------------
ggplot(q[Item == "Alimentação"], aes(Nivel, Perc, color = Edicao)) +
  geom_line(linewidth = 1) + geom_point(size = 2) + scale_color_manual(values = pof_cores_edicao()) +
  labs(title = "Participação da alimentação por quintil, RMs",
       x = "Quintil de consumo per capita (1 = 20% com menor consumo)", y = "% do consumo sem aluguel",
       color = NULL, caption = fonte) + pof_tema()

## -----------------------------------------------------------------------------
grs <- c("Alimentação", "Habitação", "Transporte", "Assistência à saúde", "Educação", "Vestuário")
ggplot(q[Item %in% grs], aes(Nivel, Perc, color = Edicao)) +
  geom_line(linewidth = 0.8) + facet_wrap(~Item, scales = "free_y", ncol = 3) +
  scale_color_manual(values = pof_cores_edicao()) +
  labs(title = "Participação por quintil, seis grupos, RMs", x = "Quintil", y = "%", color = NULL, caption = fonte) + pof_tema()

## -----------------------------------------------------------------------------
x <- dcast(e, Grupo ~ Edicao, value.var = "elasticidade")
x[, (2:6) := lapply(.SD, pof_fmt, casas = 2), .SDcols = 2:6]
knitr::kable(x, align = "lrrrrr", caption = "Elasticidade-despesa na média (Working-Leser), RMs. Abaixo de 1: bem necessário.")

## ----echo = TRUE, eval = FALSE------------------------------------------------
# bs <- pof_add_quintis(pof_sem_aluguel(b))
# pof_participacao(bs, "Alimentação", por = "Quintil_RM", filtro = quote(!is.na(RGMT)))
# pof_engel(bs[!is.na(RGMT)], pof_grupos_consumo())

