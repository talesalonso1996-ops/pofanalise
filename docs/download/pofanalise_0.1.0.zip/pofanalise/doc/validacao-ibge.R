## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE, message = FALSE, warning = FALSE, fig.width = 8, fig.height = 6, out.width = "100%")
library(pofanalise); library(data.table); library(ggplot2)
v <- pof_resultado("validacao_ibge")
com <- v[!is.na(Estimado)]
gr <- com[is.na(Item_ibge) & !grepl("^(N.mero|Tamanho)", Grupo_ibge)]
consumo <- c("Alimentação", "Habitação", "Vestuário", "Transporte", "Higiene e cuidados pessoais", "Assistência à saúde",
             "Educação", "Recreação e cultura", "Fumo", "Serviços pessoais", "Despesas diversas")
x_ <- function(ed, rec, g, it = NA, col = "Estimado") {
  r <- if (is.na(it)) v[Edicao == ed & Recorte == rec & Grupo_ibge == g & is.na(Item_ibge)] else v[Edicao == ed & Recorte == rec & Grupo_ibge == g & Item_ibge == it]
  r[[col]]
}
nf <- function(ed) v[Edicao == ed & Recorte == "Brasil" & grepl("^N.mero", Grupo_ibge)]
cg <- gr[Grupo_ibge %in% consumo]
fonte <- "Fonte: IBGE, POF 2008-2009 e 2017-2018 (tabelas de despesa e microdados harmonizados, harmonização v2 com pof_correcoes()). Pacote pofanalise."

## ----fig.alt = "Gráfico de pontos com a diferença percentual entre a estimativa do pacote e o valor oficial do IBGE para os onze grupos de consumo, em 2008-2009 e 2017-2018."----
d <- cg[Recorte == "Brasil"]
d[, Grupo_ibge := factor(Grupo_ibge, levels = rev(consumo))]
ggplot(d, aes(Dif_pct, Grupo_ibge, color = Edicao)) +
  geom_vline(xintercept = 0, color = "grey50") + geom_vline(xintercept = c(-5, 5), color = "grey80", linetype = 2) +
  geom_point(size = 3) + scale_color_manual(values = pof_cores_edicao()) +
  labs(title = "Diferença entre a estimativa do pacote e o valor oficial, Brasil",
       subtitle = "Despesa média mensal familiar por grupo; linhas tracejadas: ±5%",
       x = "Diferença (%)", y = NULL, color = NULL, caption = fonte) + pof_tema()

## -----------------------------------------------------------------------------
x <- d[order(Edicao, -Oficial), .(Edicao, Grupo = as.character(Grupo_ibge), `IBGE (reais)` = pof_fmt(Oficial, 2),
        `Pacote (reais)` = pof_fmt(Estimado, 2), `IC 95%` = paste(pof_fmt(IC_inf, 2), "a", pof_fmt(IC_sup, 2)),
        `Diferença (%)` = pof_fmt(Dif_pct, 1))]
knitr::kable(x, align = "llrrrr", caption = "Despesa média mensal familiar por grupo de consumo, Brasil")

## -----------------------------------------------------------------------------
r <- cg[, .(Grupos = .N, `Mediana |dif| (%)` = pof_fmt(median(abs(Dif_pct)), 1),
            `Até 5% (%)` = pof_fmt(100 * mean(abs(Dif_pct) <= 5), 0),
            `Oficial dentro do IC (%)` = pof_fmt(100 * mean(Oficial_no_IC), 0)), by = .(Edicao, Recorte)]
knitr::kable(r, align = "llrrrr", caption = "Grupos de consumo: concordância com o IBGE por recorte")

## -----------------------------------------------------------------------------
it <- com[!is.na(Item_ibge) & Oficial >= 5 & !grepl("Outras despesas correntes", Grupo_ibge) & Recorte == "Brasil"]
it[, dif_abs := Estimado - Oficial]
x <- it[order(-abs(dif_abs))][1:16, .(Edicao, Grupo = Grupo_ibge, Item = Item_ibge, `IBGE (reais)` = pof_fmt(Oficial, 2),
                                     `Pacote (reais)` = pof_fmt(Estimado, 2), `Diferença (reais)` = pof_fmt(dif_abs, 2))]
knitr::kable(x, align = "llllrrr", caption = "Itens com maior divergência, Brasil")

## ----echo = TRUE, eval = FALSE------------------------------------------------
# h <- pof_harmonizacao()
# b <- pof_somar_grupos(pof_ler_edicao(2017, dir, h, manter_sem_consumo = TRUE))
# v <- pof_validar(b)
# v[Recorte == "Nordeste" & is.na(Item_ibge)]
# pof_ibge("2017-2018", "Brasil")      # a tabela oficial

