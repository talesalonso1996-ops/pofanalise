## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE, message = FALSE, warning = FALSE, fig.width = 8, fig.height = 5, out.width = "100%")
library(pofanalise); library(data.table); library(ggplot2)
d <- pof_resultado("desigualdade")
drm <- pof_resultado("desigualdade_rm")
g_ <- function(rec, ed, col = "Gini") d[Recorte == rec & Edicao == ed][[col]]
qd <- dcast(drm, RM ~ Edicao, value.var = "Gini")[, dif := `2017-2018` - `2008-2009`]
fonte <- "Fonte: IBGE, POF 1987-2018, microdados harmonizados (harmonização v2 de Arthur Welle). Pacote pofanalise."

## -----------------------------------------------------------------------------
ggplot(d, aes(Edicao, Gini, color = Recorte, group = Recorte)) + geom_line(linewidth = 1) + geom_point(size = 2) +
  geom_errorbar(aes(ymin = Gini_IC_inf, ymax = Gini_IC_sup), width = 0.12, na.rm = TRUE) +
  scale_color_manual(values = c(RMs = "#1c5cab", Brasil = "#c4462c")) +
  labs(title = "Gini da despesa de consumo per capita (sem aluguel)", x = NULL, y = "Gini", color = NULL, caption = fonte) + pof_tema()

## -----------------------------------------------------------------------------
x <- d[, .(Recorte, Edicao, Gini = pof_fmt(Gini, 3),
           `IC 95%` = ifelse(is.na(Gini_IC_inf), "", paste(pof_fmt(Gini_IC_inf, 3), "a", pof_fmt(Gini_IC_sup, 3))),
           `P90/P10` = pof_fmt(P90_P10), `Top 10 (%)` = pof_fmt(Top10))]
knitr::kable(x, caption = "Medidas de desigualdade da despesa de consumo per capita")

## -----------------------------------------------------------------------------
x <- copy(qd)[, dif := NULL]
x[, (2:6) := lapply(.SD, pof_fmt, casas = 3), .SDcols = 2:6]
knitr::kable(x, caption = "Gini da despesa de consumo per capita, por RM")

