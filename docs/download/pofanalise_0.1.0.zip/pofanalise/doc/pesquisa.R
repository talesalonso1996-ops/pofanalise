## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 7.5, fig.height = 4.5, out.width = "100%")
library(pofanalise)
library(data.table)

## ----eval = FALSE-------------------------------------------------------------
# pof_buscar("aposta|loteria")
# #>   codigo   nivel  nome                                                n1
# #> 1  26101   folha  Jogos e apostas                                     26. Despesas diversas
# #> 2  26101 produto  Jogos e apostas (DESPESAS COM JOGOS E APOSTAS)      26. Despesas diversas
# #> 3  33202 produto  Outros rendimentos (GANHOS DE JOGOS ... OU PREMIOS) 33. Outros rendimentos

## ----eval = FALSE-------------------------------------------------------------
# dados <- pof_carregar(
#   anos  = c(1987, 1995, 2002, 2008, 2017),
#   dir   = "HarmonizaPOF2026_data",
#   itens = list(apostas  = "26101",
#                celular  = c("17202", "24201"),   # serviço + aparelho
#                refeicao = "16104",
#                saude    = "22"))

## -----------------------------------------------------------------------------
b <- pof_exemplo()
r <- pof_analisar(b, "Jogos", medida = "prevalencia", por = "quintil")
r
plot(r)

## ----eval = FALSE-------------------------------------------------------------
# pof_analisar(dados, "apostas")                                   # série, RMs
# pof_analisar(dados[3:5], "celular", medida = "participacao",
#              por = "quintil")                                    # Brasil, 2002 em diante
# plot(pof_analisar(dados, "refeicao", medida = "participacao", por = "quintil"))

## -----------------------------------------------------------------------------
pof_diferenca(b, "Jogos", por = "sexo", referencia = "Mulher")

## -----------------------------------------------------------------------------
pof_modelo(b, "Jogos", ~ quintil + sexo + idade)

## -----------------------------------------------------------------------------
a <- pof_exemplo(semente = 1); a$Edicao <- "2008-2009"
d <- pof_exemplo(semente = 2); d$Edicao <- "2017-2018"
dois <- list(a, d)
r <- pof_analisar(dois, "Jogos", por = "sexo")
pof_variacao(r, de = "2008-2009", para = "2017-2018")

## -----------------------------------------------------------------------------
pof_concentracao(b, c("Alimentação", "Educação", "Transporte"))

## -----------------------------------------------------------------------------
dc <- pof_decompor(dois, "Alimentação", por = "tamanho", de = "2008-2009", para = "2017-2018")
dc$resumo
dc$grupos

## ----eval = FALSE-------------------------------------------------------------
# pof_composicao(dados, "22")              # remédios, plano, consultas...
# pof_composicao(dados, "Alimentação", por = "quintil")

## -----------------------------------------------------------------------------
pof_elasticidade(b, "Alimentação", por = "sexo")[, .(Grupo, elasticidade = round(elasticidade, 2), N)]

## -----------------------------------------------------------------------------
pof_tabela(pof_analisar(dois, "Jogos", por = "quintil"))

## ----eval = FALSE-------------------------------------------------------------
# pof_exportar(pof_tabela(r), "apostas_por_sexo.csv")

## ----eval = FALSE-------------------------------------------------------------
# pof_deflacionar(pof_analisar(dados[2:5], "apostas", medida = "gasto_medio"))
# pof_analisar(dados["2017-2018"], "Alimentação", medida = "participacao", por = "regiao")

