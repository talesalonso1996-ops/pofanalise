## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(pofanalise)
library(data.table)

## ----eval = FALSE-------------------------------------------------------------
# # install.packages("remotes")
# remotes::install_github("talesalonso1996-ops/pofanalise")

## ----eval = FALSE-------------------------------------------------------------
# library(pofanalise)
# 
# h <- pof_harmonizacao()                       # de-para v2, com cache local
# b <- pof_ler_edicao(2017, dir = "HarmonizaPOF2026_data", harmonizacao = h)
# b <- pof_somar_grupos(b)                      # Alimentação, Habitação, ...
# b <- pof_add_quintis(b)                       # quintis de consumo per capita
# 
# # participação dos grupos no consumo, Brasil, com IC 95% do desenho amostral
# pof_participacao(b, pof_grupos_consumo())
# 
# # para comparar com 1987 e 1995: só RMs e sem aluguel
# bs <- pof_add_quintis(pof_sem_aluguel(b))
# pof_participacao(bs, "Alimentação", por = "Quintil_RM", filtro = quote(!is.na(RGMT)))

## -----------------------------------------------------------------------------
b <- pof_exemplo()
pof_participacao(b, c("Alimentação", "Habitação"), por = "Quintil")[, .(Nivel, Item, Perc = round(Perc, 1), IC_inf = round(IC_inf, 1), IC_sup = round(IC_sup, 1))]
pof_desigualdade(b)

## -----------------------------------------------------------------------------
pof_resultado()

