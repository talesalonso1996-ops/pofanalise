## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE, message = FALSE, warning = FALSE, fig.width = 8, fig.height = 7.5, out.width = "100%")
library(pofanalise); library(data.table); library(ggplot2)
cc <- pof_resultado("concentracao")
cr <- pof_resultado("concentracao_rms")
c17 <- cc[Edicao == "2017-2018"]
k_ <- function(nm, col = "K", ed = "2017-2018") cc[Nome == nm & Edicao == ed][[col]]
fonte <- "Fonte: IBGE, POF 2017-2018, microdados harmonizados (harmonização v2 de Arthur Welle). Pacote pofanalise."

## -----------------------------------------------------------------------------
d <- c17[Tipo == "Item"]
d[, Nome := factor(Nome, levels = d[order(K)]$Nome)]
ggplot(d, aes(K, Nome, fill = K < 0)) + geom_col(width = 0.7) +
  geom_vline(xintercept = 0, color = "grey40") +
  scale_fill_manual(values = c(`TRUE` = "#c4462c", `FALSE` = "#1c5cab"), labels = c(`TRUE` = "Regressivo", `FALSE` = "Progressivo"), name = NULL) +
  labs(title = "Índice de progressividade dos gastos, Brasil, 2017-2018",
       subtitle = "K = concentração do item menos Gini do consumo. Negativo: pesa mais para quem consome menos",
       x = "K", y = NULL, caption = fonte) + pof_tema()

## -----------------------------------------------------------------------------
x <- c17[order(K), .(Gasto = Nome, Tipo, C = pof_fmt(C, 3), K = pof_fmt(K, 3), Classificacao,
                     `Base 40% (%)` = pof_fmt(Base40), `Topo 20% (%)` = pof_fmt(Topo20))]
knitr::kable(x, align = "llrrlrr", caption = "Concentração dos gastos, Brasil, 2017-2018. Base 40%: parcela do gasto feita pelos 40% com menor consumo per capita.")

## ----fig.height = 5-----------------------------------------------------------
ggplot(cr, aes(Edicao, K, color = Nome, group = Nome)) + geom_hline(yintercept = 0, color = "grey50", linetype = 2) +
  geom_line(linewidth = 1) + geom_point() +
  labs(title = "Índice de progressividade, RMs (consumo sem aluguel)", x = NULL, y = "K", color = NULL,
       caption = "Fonte: IBGE, POF 1987-2018, microdados harmonizados. Pacote pofanalise.") +
  pof_tema() + guides(color = guide_legend(ncol = 3))

## ----echo = TRUE, eval = FALSE------------------------------------------------
# dados <- pof_carregar(c(2017), dir)
# pof_concentracao(dados, c("f17103", "f17102", "f20101", "f22301"), recorte = "brasil", sem_aluguel = FALSE)

