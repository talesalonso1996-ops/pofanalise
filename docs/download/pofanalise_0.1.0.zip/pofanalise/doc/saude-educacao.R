## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE, message = FALSE, warning = FALSE, fig.width = 8, fig.height = 5, out.width = "100%")
library(pofanalise); library(data.table); library(ggplot2)
s <- pof_resultado("saude_educacao_quintil_rms")[, Nome := pof_rotulo(Item)]
pb <- pof_resultado("prevalencia_quintil_brasil")[, Nome := pof_rotulo(Item)]
s_ <- function(cod, ed, k) s[Item == cod & Edicao == ed & Nivel == k]$Perc
b_ <- function(cod, ed, k) pb[Item == cod & Edicao == ed & Nivel == k]
ic <- function(r) paste0(pof_fmt(r$Perc), "% (IC 95%: ", pof_fmt(r$IC_inf), " a ", pof_fmt(r$IC_sup), ")")
fonte <- "Fonte: IBGE, POF 1987-2018, microdados harmonizados (harmonização v2 de Arthur Welle). Pacote pofanalise."

## -----------------------------------------------------------------------------
d <- pb[, .(Nome, Nivel, Edicao, Perc, IC_inf, IC_sup)]
ggplot(d, aes(factor(Nivel), Perc, fill = Edicao)) +
  geom_col(position = position_dodge(0.8), width = 0.75) +
  geom_errorbar(aes(ymin = IC_inf, ymax = IC_sup), position = position_dodge(0.8), width = 0.25, color = "grey30") +
  facet_wrap(~Nome, scales = "free_y") + scale_fill_manual(values = pof_cores_edicao()) +
  labs(title = "UCs com gasto em plano de saúde e ensino pago, Brasil", subtitle = "Barras: IC 95% do desenho amostral",
       x = "Quintil", y = "% das UCs", fill = NULL, caption = fonte) + pof_tema()

## -----------------------------------------------------------------------------
x <- pb[, .(Nome, Quintil = Nivel, Edicao, v = paste0(pof_fmt(Perc), " [", pof_fmt(IC_inf), "; ", pof_fmt(IC_sup), "]"))]
knitr::kable(dcast(x, Nome + Quintil ~ Edicao, value.var = "v"), caption = "Proporção de UCs com gasto, Brasil, IC 95% (%)")

## ----echo = TRUE, eval = FALSE------------------------------------------------
# dados <- pof_carregar(c(2002, 2008, 2017), dir, itens = list(plano = "22301", superior = "23102"))
# plot(pof_analisar(dados, "plano", por = "quintil"))
# pof_diferenca(dados, "superior", por = "cor")

