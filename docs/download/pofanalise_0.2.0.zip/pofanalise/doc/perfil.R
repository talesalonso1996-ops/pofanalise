## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE, message = FALSE, warning = FALSE, fig.width = 8.5, fig.height = 6, out.width = "100%")
library(pofanalise); library(data.table); library(ggplot2)
pi <- pof_resultado("perfil_indice")
pp <- pof_resultado("perfil_participacao")
i_ <- function(dim, nv, ed, col = "Indice_consumo_pc") pi[Dimensao == dim & Nivel == nv & Edicao == ed][[col]]
p_ <- function(dim, nv, gr, ed) pp[Dimensao == dim & Nivel == nv & Item == gr & Edicao == ed]$Perc
fonte <- "Fonte: IBGE, POF 1987-2018, microdados harmonizados (harmonização v2 de Arthur Welle). Pacote pofanalise."
rot <- c(Cor = "Cor da pessoa de referência", Faixa_etaria = "Idade da pessoa de referência",
         Sexo = "Sexo da pessoa de referência", Tamanho = "Moradores na UC")

## ----fig.alt = "Gráfico: Consumo per capita relativo à média da edição (= 100), RMs"----
ult <- pi[, .SD[Edicao == max(Edicao)], by = .(Dimensao, Nivel)]
ggplot(pi, aes(Edicao, Indice_consumo_pc, color = Nivel, group = Nivel)) +
  geom_hline(yintercept = 100, linetype = 2, color = "grey50") + geom_line(linewidth = 1) + geom_point() +
  geom_text(data = ult, aes(label = Nivel), hjust = 0, nudge_x = 0.12, size = 3.2) +
  scale_x_discrete(expand = expansion(add = c(0.3, 1.8))) +
  facet_wrap(~Dimensao, labeller = as_labeller(rot)) +
  labs(title = "Consumo per capita relativo à média da edição (= 100), RMs", x = NULL, y = "Índice", caption = fonte) +
  pof_tema() + theme(legend.position = "none", axis.text.x = element_text(angle = 45, hjust = 1))

## -----------------------------------------------------------------------------
x <- pp[Edicao == "2017-2018", .(Dimensao = rot[Dimensao], Categoria = Nivel, Item, Perc)]
x <- dcast(x, Dimensao + Categoria ~ Item, value.var = "Perc")
x[, (3:ncol(x)) := lapply(.SD, pof_fmt), .SDcols = 3:ncol(x)]
knitr::kable(x, caption = "Participação no consumo sem aluguel segundo o perfil, RMs, 2017-2018 (%)")

## ----echo = TRUE, eval = FALSE------------------------------------------------
# dados <- pof_carregar(dir = dir)
# pof_analisar(dados, "Alimentação", medida = "participacao", por = "cor")
# pof_modelo(dados[3:5], "Educação", ~ quintil + cor + sexo + idade)

