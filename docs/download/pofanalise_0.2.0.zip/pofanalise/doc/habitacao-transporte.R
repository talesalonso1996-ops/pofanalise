## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE, message = FALSE, warning = FALSE, fig.width = 8, fig.height = 5, out.width = "100%")
library(pofanalise); library(data.table); library(ggplot2)
it <- pof_resultado("itens_rms")[, Nome := pof_rotulo(Item)]
iq <- pof_resultado("itens_quintil_rms")[, Nome := pof_rotulo(Item)]
pv <- pof_resultado("prevalencia_rms")
i_ <- function(cod, ed) it[Item == cod & Edicao == ed]$Perc
p_ <- function(cod, ed) pv[Item == cod & Edicao == ed]$Perc
q_ <- function(cod, ed, k) iq[Item == cod & Edicao == ed & Nivel == k]$Perc
fonte <- "Fonte: IBGE, POF 1987-2018, microdados harmonizados (harmonização v2 de Arthur Welle). Pacote pofanalise."

## ----fig.alt = "Gráfico: Itens de habitação e transporte, RMs"----------------
d <- it[!Item %in% c("f17101", "Habitação", "Transporte")]
ggplot(d, aes(Edicao, Perc, color = Nome, group = Nome)) + geom_line(linewidth = 1) + geom_point() +
  labs(title = "Itens de habitação e transporte, RMs", x = NULL, y = "% do consumo sem aluguel",
       color = NULL, caption = fonte) + pof_tema() + guides(color = guide_legend(ncol = 2))

## ----fig.alt = "Gráfico: Habitação, transporte, transporte urbano e veículo por quintil, RMs"----
ggplot(iq, aes(Nivel, Perc, color = Edicao)) + geom_line(linewidth = 0.9) +
  facet_wrap(~Nome, scales = "free_y") + scale_color_manual(values = pof_cores_edicao()) +
  labs(title = "Habitação, transporte, transporte urbano e veículo por quintil, RMs",
       x = "Quintil", y = "% do consumo sem aluguel", color = NULL, caption = fonte) + pof_tema()

## ----echo = TRUE, eval = FALSE------------------------------------------------
# dados <- pof_carregar(dir = dir, itens = list(onibus = "20101", veiculo = "20301"))
# pof_analisar(dados, "onibus", medida = "prevalencia")
# plot(pof_analisar(dados, "onibus", medida = "participacao", por = "quintil"))

