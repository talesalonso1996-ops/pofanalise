## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE, message = FALSE, warning = FALSE, fig.width = 8, fig.height = 4.6, out.width = "100%")
library(pofanalise); library(data.table); library(ggplot2)
q  <- pof_resultado("quintis_rms")
g  <- pof_resultado("grupos")[Recorte == "RMs, sem aluguel"]
a  <- pof_resultado("alimentacao_rms")
pb <- pof_resultado("prevalencia_quintil_brasil")
d  <- pof_resultado("desigualdade")
pi <- pof_resultado("perfil_indice")
cmp <- pof_resultado("comparacao_ibge")
qv <- function(it, ed, k) q[Item == it & Edicao == ed & Nivel == k]$Perc
rz <- function(it, ed) qv(it, ed, 1) / qv(it, ed, 5)
gv <- function(it, ed) g[Item == it & Edicao == ed]$Perc
pbv <- function(cod, ed, k) pb[Item == cod & Edicao == ed & Nivel == k]$Perc
gi <- function(rec, ed) d[Recorte == rec & Edicao == ed]$Gini
piv <- function(dim, nv, ed) pi[Dimensao == dim & Nivel == nv & Edicao == ed]$Indice_consumo_pc
fonte <- "Fonte: IBGE, POF 1987-2018, microdados harmonizados (harmonização v2 de Arthur Welle). Pacote pofanalise."

## ----fig.alt = "Gráfico: Razão entre a participação no 1º e no 5º quintil, RMs"----
r <- rbindlist(lapply(c("Alimentação", "Habitação", "Transporte", "Educação"), function(it)
  data.table(Item = it, Edicao = unique(q$Edicao), Razao = sapply(unique(q$Edicao), function(e) rz(it, e)))))
ggplot(r, aes(Edicao, Razao, color = Item, group = Item)) +
  geom_hline(yintercept = 1, linetype = 2, color = "grey50") + geom_line(linewidth = 1) + geom_point(size = 2) +
  labs(title = "Razão entre a participação no 1º e no 5º quintil, RMs",
       subtitle = "Acima de 1: o grupo pesa mais no orçamento dos 20% com menor consumo",
       x = NULL, y = "Razão Q1/Q5", color = NULL, caption = fonte) + pof_tema()

