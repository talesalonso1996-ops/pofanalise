## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE, message = FALSE, warning = FALSE, fig.width = 8, fig.height = 5.5, out.width = "100%")
library(pofanalise); library(data.table); library(ggplot2)
dc <- pof_resultado("decomposicao")
dg <- pof_resultado("decomposicao_grupos")
r_ <- function(it, pr, col, de = "1995-1996") dc[Item == it & Por == pr & De == de][[col]]
g_ <- function(it, pr, gr, col, de = "1995-1996") dg[Item == it & Por == pr & Grupo == gr & De == de][[col]]
fonte <- "Fonte: IBGE, POF 1995-2018, microdados harmonizados (harmonização v2 de Arthur Welle). Pacote pofanalise."

## ----fig.alt = "Gráfico: Decomposição da variação da participação, RMs, 1995-1996 a 2017-2018"----
d <- melt(dc[De == "1995-1996"], id.vars = c("Item", "Por"), measure.vars = c("Efeito_comportamento", "Efeito_composicao"),
          variable.name = "Efeito", value.name = "pp")
d[, Efeito := fifelse(Efeito == "Efeito_comportamento", "Comportamento", "Composição")]
d[, Por := c(idade = "Idade da pessoa de referência", tamanho = "Moradores na UC", sexo = "Sexo da pessoa de referência")[Por]]
ggplot(d, aes(pp, Item, fill = Efeito)) + geom_col(width = 0.65) + geom_vline(xintercept = 0, color = "grey40") +
  facet_wrap(~Por, ncol = 1) + scale_fill_manual(values = c(Comportamento = "#1c5cab", `Composição` = "#eb6834")) +
  labs(title = "Decomposição da variação da participação, RMs, 1995-1996 a 2017-2018",
       x = "Pontos percentuais do consumo sem aluguel", y = NULL, fill = NULL, caption = fonte) + pof_tema()

## -----------------------------------------------------------------------------
x <- dc[, .(Grupo = Item, Corte = Por, Periodo = paste(substr(De, 1, 4), "a", substr(Para, 1, 4)),
            `Variação (p.p.)` = pof_fmt(Variacao_total, 2), Comportamento = pof_fmt(Efeito_comportamento, 2),
            `Composição` = pof_fmt(Efeito_composicao, 2))]
knitr::kable(x, align = "lllrrr", caption = "Decomposição da variação da participação no consumo sem aluguel, RMs")

## ----echo = TRUE, eval = FALSE------------------------------------------------
# dados <- pof_carregar(c(1995, 2017), dir)
# d <- pof_decompor(dados, "Assistência à saúde", por = "idade", de = "1995-1996", para = "2017-2018")
# d$resumo; d$grupos

