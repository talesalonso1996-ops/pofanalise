## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE, message = FALSE, warning = FALSE, fig.width = 8, fig.height = 7.5, out.width = "100%")
library(pofanalise); library(data.table); library(ggplot2)
m <- pof_resultado("variacao_2008_2017")
cp <- pof_resultado("composicao_saude_habitacao")
mp <- m[Medida == "participacao"]; mv <- m[Medida == "prevalencia"]
x_ <- function(d, nm, col = "Diferenca") d[Nome == nm][[col]]
cpv <- function(nm, ed) cp[Parte == nm & Edicao == ed]$Perc
fonte <- "Fonte: IBGE, POF 2008-2009 e 2017-2018, microdados harmonizados (harmonização v2 de Arthur Welle). Pacote pofanalise."

## ----fig.alt = "Gráfico: Variação da participação no consumo, 2008-2009 a 2017-2018, Brasil"----
d <- mp[order(Diferenca)][, Nome := factor(Nome, levels = Nome)]
ggplot(d, aes(Diferenca, Nome, color = Significativa)) +
  geom_vline(xintercept = 0, color = "grey50") +
  geom_errorbarh(aes(xmin = IC_inf, xmax = IC_sup), height = 0.3) + geom_point(size = 2) +
  scale_color_manual(values = c(`TRUE` = "#1c5cab", `FALSE` = "grey60"), labels = c(`TRUE` = "Significativa (p < 0,05)", `FALSE` = "Não significativa"), name = NULL) +
  labs(title = "Variação da participação no consumo, 2008-2009 a 2017-2018, Brasil",
       subtitle = "Pontos percentuais, com IC 95%", x = "p.p.", y = NULL, caption = fonte) + pof_tema()

## -----------------------------------------------------------------------------
x <- mv[Tipo == "Item"][order(Diferenca), .(Item = Nome, `2008-2009` = pof_fmt(De), `2017-2018` = pof_fmt(Para),
        `Diferença (p.p.)` = pof_fmt(Diferenca), `IC 95%` = paste(pof_fmt(IC_inf), "a", pof_fmt(IC_sup)),
        p = ifelse(p_valor < 0.001, "< 0,001", pof_fmt(p_valor, 3)))]
knitr::kable(x, align = "lrrrrr", caption = "Proporção de UCs com gasto no item (%), Brasil")

## ----fig.height = 6, fig.alt = "Gráfico: Composição da saúde e dos serviços de habitação, Brasil"----
ggplot(cp[Perc >= 1], aes(Edicao, Perc, fill = Parte)) + geom_col(width = 0.65, color = "white", linewidth = 0.3) +
  facet_wrap(~Grupo_pai) +
  labs(title = "Composição da saúde e dos serviços de habitação, Brasil", x = NULL, y = "% do gasto do grupo",
       fill = NULL, caption = "Partes com menos de 1% omitidas. Pacote pofanalise.") +
  pof_tema() + guides(fill = guide_legend(ncol = 2))

## ----echo = TRUE, eval = FALSE------------------------------------------------
# dados <- pof_carregar(c(2008, 2017), dir)
# r <- pof_analisar(dados, "f20101", medida = "prevalencia", recorte = "brasil", sem_aluguel = FALSE)
# pof_variacao(r, "2008-2009", "2017-2018")
# pof_composicao(dados, "22")

