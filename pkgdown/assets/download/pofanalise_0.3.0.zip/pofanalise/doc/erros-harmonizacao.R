## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE, message = FALSE, warning = FALSE)
library(pofanalise); library(data.table)
cr <- pof_correcoes()
cv <- pof_resultado("comparacao_versoes")
vo <- tryCatch(pof_resultado("validacao_ibge_v2_original"), error = function(e) NULL)
vi <- pof_resultado("validacao_ibge")
f1 <- function(x) pof_fmt(x, 1); f2 <- function(x) pof_fmt(x, 2)
sg <- function(x) paste0(ifelse(round(x, 2) > 0, "+", ""), ifelse(abs(x) < 0.005, "0,00", pof_fmt(x, 2)), "%")
cons <- function(v, ed) v[Edicao == ed & Recorte == "Brasil" & Grupo_ibge == "Despesas de consumo" & is.na(Item_ibge)]

## -----------------------------------------------------------------------------
if (!is.null(vo)) {
  ord <- c("Despesas de consumo", "Alimentação", "Habitação", "Vestuário", "Transporte", "Higiene e cuidados pessoais",
           "Assistência à saúde", "Educação", "Recreação e cultura", "Fumo", "Serviços pessoais", "Despesas diversas",
           "Outras despesas correntes", "Aumento do ativo")
  a <- vo[Recorte == "Brasil" & is.na(Item_ibge) & Grupo_ibge %in% ord, .(Edicao, Grupo_ibge, Oficial, Antes = Dif_pct)]
  b <- vi[Recorte == "Brasil" & is.na(Item_ibge) & Grupo_ibge %in% ord, .(Edicao, Grupo_ibge, Depois = Dif_pct)]
  x <- merge(a, b, by = c("Edicao", "Grupo_ibge"))
  x[, Grupo_ibge := factor(Grupo_ibge, levels = ord)]
  x <- x[order(Edicao, Grupo_ibge), .(Edicao, Grupo = as.character(Grupo_ibge), `IBGE (R$)` = f2(Oficial),
                                      `v2 sem correções` = sg(Antes), `Com as correções` = sg(Depois))]
  knitr::kable(x, align = "llrrr", caption = "Diferença entre a estimativa e o valor oficial do IBGE, despesa média mensal familiar, Brasil")
}

## -----------------------------------------------------------------------------
y <- dcast(cv[Recorte == "RMs, sem aluguel" & versao %in% c("v2 original", "v2 com correções")], Edicao + Item ~ versao, value.var = "Perc")
y[, d := `v2 com correções` - `v2 original`]
z <- dcast(y, Item ~ Edicao, value.var = "d")
z[, (2:ncol(z)) := lapply(.SD, function(v) ifelse(abs(v) < 0.005, "0,00", paste0(ifelse(v > 0, "+", ""), f2(v)))), .SDcols = 2:ncol(z)]
knitr::kable(z, col.names = c("Grupo", names(z)[-1]), align = "lrrrrr",
             caption = "Efeito das correções na participação dos grupos, RMs, consumo sem aluguel (p.p.)")

## -----------------------------------------------------------------------------
h0 <- tryCatch(pof_harmonizacao(correcoes = FALSE), error = function(e) NULL)
x <- copy(cr)
if (!is.null(h0)) x <- merge(x, h0$depara[, .(ano, codigo, v2 = cod_final)], by = c("ano", "codigo"), all.x = TRUE, sort = FALSE)
setcolorder(x, intersect(c("ano", "codigo", "item", "erro", "v2", "cod_final"), names(x)))
knitr::kable(x, col.names = c("Ano", "Código", "Item", "Erro", if (!is.null(h0)) "Folha na v2", "Folha usada")[seq_len(ncol(x))],
             caption = "Códigos reclassificados por pof_correcoes()")

